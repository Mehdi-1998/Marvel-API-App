//
//  Credentials.swift
//  Marvel API
//
//

import SwiftUI

let privateKey = "5ef4c040542ae259574b7d3873da108a42148ef3"
let publicKey = "b70d27f423351df4a91de11fcc978031"
