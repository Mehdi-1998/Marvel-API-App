//
//  CharactersView.swift
//  Marvel API
//
//

import SwiftUI
import SDWebImageSwiftUI

struct CharactersView: View {
    @EnvironmentObject var homeData: HomeViewModel
    var body: some View {

        // Navigation View...
        NavigationView{
            
            ScrollView(.vertical, showsIndicators: false, content: {
                
                VStack(spacing: 15){
                    
                    // Search Bar...
                    HStack(spacing: 10){
                        
                        Image(systemName: "magnifyingglass")
                            
                        TextField("Search", text: $homeData.searchQuery)
                    }
                    .padding(.vertical,10)
                    .padding(.horizontal)
                    .background(Color.yellow)
   
                }
                .padding()
                
                if let characters = homeData.fetchedCharacters{
                    
                    if characters.isEmpty{
                        // No results...
                        Text("No Results Found")
                            .padding(.top,20)
                    }
                    else{
                        
                        // Displaying results....
                        ForEach(characters){data in
                            
                            CharacterRowView(character: data)
                        }
                    }
                }
                else{
                    if homeData.searchQuery != ""{
                        // Loading Screem...
                        ProgressView()
                            .padding(.top,20)
                    }
                }
            })
            .navigationTitle("Search for a Character")
        }
    }
}

struct CharactersView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct CharacterRowView: View {
    
    var character: Character
    
    var body: some View{
        
        HStack(alignment: .top,spacing: 15){
            
            WebImage(url: extractImage(data: character.thumbnail))
                .resizable()
                .frame(width: 150, height: 150)
            
            VStack(alignment: .leading, spacing: 8, content: {
                
                Text(character.name)
                    .font(.title3)
                
                Text(character.description)

            })
            
            Spacer(minLength: 0)
        }
        .padding(.horizontal)
    }
    
    func extractImage(data: [String: String])->URL{
        
        // combining both and forming image...
        let path = data["path"] ?? ""
        let ext = data["extension"] ?? ""
        
        return URL(string: "\(path).\(ext)")!
    }

}
