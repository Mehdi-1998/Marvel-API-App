//
//  Marvel_APIApp.swift
//  Shared
//
//

import SwiftUI

@main
struct Marvel_APIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
